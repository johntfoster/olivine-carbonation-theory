#!/usr/bin/env python3
"""Create a new read-only self-contained review snapshot from an explicit allowlist."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile

DEFAULT_INCLUDE = ('paper', 'verification', 'scripts', 'docs/source-inventory.md',
                   'docs/review-workflow.md', 'docs/rebuild-source-contract.md',
                   'docs/rebuild-derivation-notes.md', 'GOAL.md', 'README.md',
                   'LICENSES.md', 'licenses', 'environment', 'CITATION.cff',
                   'research-project.yml', 'Makefile', 'build/main.pdf', 'build/main.log',
                   'build/build-command.log', 'build/build-provenance.json', 'figures', 'data',
                   'moose_app/Makefile', 'moose_app/src', 'moose_app/include',
                   'moose_app/examples', 'moose_app/test/tests', 'tools/moose-run',
                   'docs/numerical-verification-plan.md', 'AGENTS.md', 'agent-profile.json',
                   'PLAN.md', 'docs/implementation-status.md')
EXCLUDED = {'.git', '.agent-runtime', 'reviews', '.agent', '.agents', '.claude',
            '.opencode', '__pycache__', 'private', 'attachments', 'credentials', 'secrets'}
POLICY = 'scripts/review_snapshot_policy.json'
REVIEW_REPORT = re.compile(r'(?:reviewer[-_]?\d|foster[-_]?(?:cycle|review)|response[-_]?matrix)', re.I)


def relative_path(item):
    rel = Path(item)
    if (not rel.parts or rel.is_absolute() or '..' in rel.parts
            or any(p.lower() in EXCLUDED for p in rel.parts)):
        raise ValueError(f'forbidden include: {item}')
    return rel


def public_inputs(root, manifest_paths):
    """Load only explicitly declared, already present, hash-pinned public inputs."""
    declared = {}
    for item in manifest_paths:
        rel = relative_path(item)
        path = root / rel
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'public-input manifest must be a regular file: {item}')
        entries = json.loads(path.read_text())['inputs']
        declared[rel.as_posix()] = None
        for entry in entries:
            name = relative_path(entry['path']).as_posix()
            if (entry.get('public') is not True
                    or not entry.get('source_url', '').startswith('https://')
                    or not entry.get('license')
                    or not re.fullmatch('[0-9a-f]{64}', entry.get('sha256', ''))):
                raise ValueError(f'incomplete public-input provenance: {name}')
            source = root / name
            if source.is_symlink() or not source.is_file():
                raise ValueError(f'declared public input missing/nonregular: {name}')
            if hashlib.sha256(source.read_bytes()).hexdigest() != entry['sha256']:
                raise ValueError(f'declared public input hash mismatch: {name}')
            if name in declared and declared[name] != entry['sha256']:
                raise ValueError(f'conflicting public-input declaration: {name}')
            declared[name] = entry['sha256']
    return declared


def payload(root, includes, declared=None):
    files = {}
    for item in includes:
        rel = relative_path(item)
        source = root / rel
        if any((root / Path(*rel.parts[:i])).is_symlink() for i in range(1, len(rel.parts) + 1)):
            raise ValueError(f'symlinks cannot enter an independent snapshot: {rel}')
        if not source.exists():
            raise ValueError(f'required review input missing: {item}')
        candidates = sorted(source.rglob('*')) if source.is_dir() else [source]
        for path in candidates:
            name = path.relative_to(root)
            if any(p.lower() in EXCLUDED for p in name.parts):
                continue
            if REVIEW_REPORT.search(path.name):
                raise ValueError(f'prior review/editorial report cannot enter snapshot: {name}')
            if path.is_symlink():
                raise ValueError(f'symlinks cannot enter an independent snapshot: {name}')
            if path.is_file():
                if path.suffix in {'.pyc', '.pyo'}:
                    continue
                files[name.as_posix()] = path
    policy = json.loads((root / POLICY).read_text())
    for required in policy['required_files']:
        if required not in files:
            raise ValueError(f'self-contained review requires {required}')
    # Optional science directories cannot silently disappear through a replacement allowlist.
    for item in policy['scientific_paths']:
        base = root / relative_path(item)
        if not base.exists():
            continue
        candidates = base.rglob('*') if base.is_dir() else [base]
        for path in candidates:
            rel = path.relative_to(root)
            if (path.is_file() and not any(p.lower() in EXCLUDED for p in rel.parts)
                    and path.suffix not in {'.pyc', '.pyo'} and rel.as_posix() not in files):
                raise ValueError(f'existing supporting science omitted: {rel}; include it explicitly')
    for name, expected in (declared or {}).items():
        if name not in files:
            raise ValueError(f'declared public input omitted: {name}')
        if expected and hashlib.sha256(files[name].read_bytes()).hexdigest() != expected:
            raise ValueError(f'declared public input changed while collecting: {name}')
    for name in files:
        if name.startswith('source-snapshots/') and not (declared or {}).get(name):
            raise ValueError(f'source-snapshot input needs public provenance declaration: {name}')
    provenance = json.loads((root / 'build/build-provenance.json').read_text())
    if set(provenance.get('outputs', {})) != {'build/main.pdf', 'build/main.log', 'build/build-command.log'}:
        raise ValueError('build provenance must bind PDF, TeX log and command log')
    source_names = {name for name in files if name.startswith(('paper/', 'sections/', 'figures/'))
                    or ('/' not in name and Path(name).suffix in {'.tex', '.bib', '.sty', '.cls', '.bst'})}
    if set(provenance.get('sources', {})) != source_names:
        raise ValueError('build provenance source set differs from current payload; rebuild explicitly')
    for group in ('sources', 'outputs'):
        if not provenance.get(group):
            raise ValueError(f'build provenance lacks {group}')
        for name, expected in provenance[group].items():
            name = relative_path(name).as_posix()
            if name not in files:
                raise ValueError(f'build provenance input/output omitted: {name}')
            if hashlib.sha256(files[name].read_bytes()).hexdigest() != expected:
                raise ValueError(f'build provenance hash mismatch: {name}; rebuild explicitly')
    evidence = json.loads((root / 'verification/analytical_report.json').read_text())
    summary = evidence.get('summary', evidence)
    if not isinstance(summary.get('total'), int) or summary['total'] <= 0 or summary.get('passed') != summary['total']:
        raise ValueError('analytical evidence must record a positive total and all checks passed')
    for key, name in [('manuscript_sha256', 'paper/main.tex'),
                      ('script_sha256', 'verification/check_theory.py')]:
        expected = evidence.get('inputs', {}).get(name, evidence.get(key))
        if expected != hashlib.sha256(files[name].read_bytes()).hexdigest():
            raise ValueError(f'analytical evidence stale/missing {key}; rerun the scientific checks')
    for name, expected in evidence.get('inputs', {}).items():
        if name not in files or hashlib.sha256(files[name].read_bytes()).hexdigest() != expected:
            raise ValueError(f'analytical evidence input missing or stale: {name}')
    for report_name, source_key, data_key in [
            ('verification/silica-results.json', 'sources', 'data_hashes'),
            ('verification/silica-jacobian-results.json', 'source_hashes', None),
            ('verification/implementation-results.json', 'source_hashes', None)]:
        numerical = json.loads(files[report_name].read_text())
        if numerical.get('status') != 'passed':
            raise ValueError(f'numerical evidence is not passed: {report_name}')
        for key in (source_key, data_key):
            if key is None:
                continue
            for name, expected in numerical.get(key, {}).items():
                if name not in files or hashlib.sha256(files[name].read_bytes()).hexdigest() != expected:
                    raise ValueError(f'numerical evidence input missing or stale: {name}')
        if numerical.get('moose_revision', 'abafb58b67a6037c6723ffeb19647c84484466da') != 'abafb58b67a6037c6723ffeb19647c84484466da':
            raise ValueError(f'numerical evidence uses an unpinned framework: {report_name}')
    return files


def verify(snapshot):
    manifest_path = snapshot / 'MANIFEST.json'
    manifest = manifest_path.read_bytes()
    snapshot_id = hashlib.sha256(manifest).hexdigest()
    if (snapshot / 'SNAPSHOT_ID').read_text().strip() != snapshot_id:
        raise ValueError('snapshot ID does not match manifest')
    records = json.loads(manifest)
    paths = [record['path'] for record in records]
    if len(paths) != len(set(paths)) or paths != sorted(paths):
        raise ValueError('manifest paths must be unique and sorted')
    found = set()
    for path in [snapshot, *snapshot.rglob('*')]:
        if path.is_symlink():
            raise ValueError(f'snapshot contains symlink: {path}')
        if path.stat().st_mode & 0o222:
            raise ValueError(f'snapshot entry is writable: {path}')
        if path.is_file():
            found.add(path.relative_to(snapshot).as_posix())
    if found != set(paths) | {'MANIFEST.json', 'SNAPSHOT_ID'}:
        raise ValueError('snapshot file set does not match manifest')
    for record in records:
        path = snapshot / relative_path(record['path'])
        if hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
            raise ValueError(f'snapshot hash mismatch: {record["path"]}')
        if path.stat().st_size != record['bytes']:
            raise ValueError(f'snapshot size mismatch: {record["path"]}')
    return {'passed': True, 'snapshot_id': snapshot_id, 'files': len(records)}


def freeze(root, round_name, includes, manifest_paths=()):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', round_name):
        raise ValueError('round must be a simple identifier')
    base = root / '.agent-runtime/review-snapshots'
    dest = base / round_name
    if dest.exists():
        raise ValueError(f'round already exists; never replace immutable evidence: {dest}')
    declared = public_inputs(root, manifest_paths)
    files = payload(root, (*includes, *declared), declared)
    base.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.new-', dir=base))
    try:
        records = []
        for rel, source in sorted(files.items()):
            target = staging / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            shutil.copyfile(source, target)
            copied = hashlib.sha256(target.read_bytes()).hexdigest()
            if before != copied or copied != hashlib.sha256(source.read_bytes()).hexdigest():
                raise ValueError(f'input changed while freezing: {rel}')
            records.append({'path': rel, 'sha256': copied, 'bytes': target.stat().st_size})
        # Recheck the complete input set after copying. This is a race detector,
        # not a substitute for coordinator-enforced single-writer quiescence.
        final = payload(root, (*includes, *declared), declared)
        if set(final) != set(files):
            raise ValueError('input file set changed while freezing')
        for record in records:
            if hashlib.sha256(final[record['path']].read_bytes()).hexdigest() != record['sha256']:
                raise ValueError(f'input changed while freezing: {record["path"]}')
        context = (json.dumps({'includes': list(includes),
                               'public_input_manifests': list(manifest_paths),
                               'public_inputs': declared}, indent=2, sort_keys=True) + '\n').encode()
        (staging / 'SNAPSHOT_CONTEXT.json').write_bytes(context)
        records.append({'path': 'SNAPSHOT_CONTEXT.json',
                        'sha256': hashlib.sha256(context).hexdigest(), 'bytes': len(context)})
        records.sort(key=lambda record: record['path'])
        manifest = (json.dumps(records, indent=2, sort_keys=True) + '\n').encode()
        (staging / 'MANIFEST.json').write_bytes(manifest)
        snapshot_id = hashlib.sha256(manifest).hexdigest()
        (staging / 'SNAPSHOT_ID').write_text(snapshot_id + '\n')
        for entry in staging.rglob('*'):
            entry.chmod(0o555 if entry.is_dir() else 0o444)
        staging.chmod(0o555)
        staging.rename(dest)
    except Exception:
        for entry in staging.rglob('*'):
            entry.chmod(0o755 if entry.is_dir() else 0o644)
        staging.chmod(0o755)
        shutil.rmtree(staging)
        raise
    verify(dest)
    return {'round': round_name, 'snapshot': str(dest), 'snapshot_id': snapshot_id,
            'files': len(records), 'report_paths': [f'reviews/{round_name}/reviewer-{n}.md' for n in (1, 2, 3)]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    operation = parser.add_mutually_exclusive_group(required=True)
    operation.add_argument('--round')
    operation.add_argument('--verify', type=Path, help='Verify an existing immutable snapshot')
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--include', action='append', help='Explicit complete replacement allowlist; repeat per path')
    parser.add_argument('--public-input-manifest', action='append', default=[],
                        help='Append hash-pinned declared public inputs and their manifest')
    args = parser.parse_args()
    try:
        if args.verify:
            print(json.dumps(verify(args.verify.resolve()), indent=2))
            return
        print(json.dumps(freeze(args.root.resolve(), args.round, args.include or DEFAULT_INCLUDE,
                                args.public_input_manifest), indent=2))
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.error(str(exc))


if __name__ == '__main__':
    main()
