#!/usr/bin/env python3
"""Check necessary (not sufficient) conditions for a prose-only editorial change."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

MATH = re.compile(r'\\\[(.*?)\\\]|\\\((.*?)\\\)|\$\$(.*?)\$\$|(?<!\\)\$(.*?)(?<!\\)\$|\\begin\{((?:equation|align|alignat|flalign|gather|multline|eqnarray|displaymath|math|split|cases|matrix|pmatrix|bmatrix|Bmatrix|vmatrix|Vmatrix)\*?)\}(.*?)\\end\{\5\}', re.S)
STRUCTURE = re.compile(r'\\(?:begin|end)\{[^}]+\}|\\(?:section|subsection|subsubsection|chapter|paragraph)\*?\b')
REFS = re.compile(r'\\(?:[A-Za-z]*cite[A-Za-z]*|label|(?:eq|page|auto|name|[cCvV])?ref|[cC]refrange|hyperref)\*?(?:\[[^]]*\])*\{[^}]*\}')
SYMBOLS = re.compile(r'\\[A-Za-z]+')
DIGITS = re.compile(r'[-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?')
DEFINITIONS = re.compile(r'\\(?:newcommand|renewcommand|providecommand|DeclareMathOperator|def|gdef|edef|xdef|let|newenvironment|renewenvironment)\b')
BRACED_MATH = re.compile(r'\\(?:ensuremath|mbox|hbox)\b')
POLICY = 'scripts/review_snapshot_policy.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def source_text(text):
    cleaned = []
    for line in text.splitlines():
        for pos, char in enumerate(line):
            if char == '%':
                preceding = len(line[:pos]) - len(line[:pos].rstrip('\\'))
                if preceding % 2 == 0:
                    line = line[:pos]
                    break
        cleaned.append(line)
    return '\n'.join(cleaned)


def protected_commands(text, pattern):
    """Conservatively hash macro-definition/braced-math spans through balanced braces."""
    spans = []
    for match in pattern.finditer(text):
        end = text.find('\n', match.end())
        if end == -1:
            end = len(text)
        balance = text[match.start():end].count('{') - text[match.start():end].count('}')
        while balance > 0 and end < len(text):
            following = text.find('\n', end + 1)
            following = len(text) if following == -1 else following
            balance += text[end:following].count('{') - text[end:following].count('}')
            end = following
        spans.append(digest(text[match.start():end].encode()))
    return spans


def invariants(data):
    text = source_text(data.decode('utf-8'))
    return {'structural_tokens': dict(sorted(Counter(STRUCTURE.findall(text)).items())),
            'digit_literals': dict(sorted(Counter(DIGITS.findall(text)).items())),
            'math_block_hashes': [digest(m.group(0).encode()) for m in MATH.finditer(text)],
            'citation_label_reference_tokens': dict(sorted(Counter(REFS.findall(text)).items())),
            'symbol_commands': dict(sorted(Counter(SYMBOLS.findall(text)).items())),
            'unicode_greek_symbols': dict(sorted(Counter(re.findall('[\u0370-\u03ff\u1f00-\u1fff]', text)).items())),
            'macro_definitions': protected_commands(text, DEFINITIONS),
            'braced_math_commands': protected_commands(text, BRACED_MATH)}


def files(root, scientific_paths=None):
    selected = {}
    if scientific_paths is None:
        scientific_paths = json.loads((root / POLICY).read_text())['scientific_paths']
    paths = list(scientific_paths)
    paths.extend(path.name for path in root.iterdir()
                 if path.suffix in {'.tex', '.bib', '.sty', '.cls', '.bst'})
    for folder in paths:
        rel = Path(folder)
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError(f'scientific path must be root-relative: {folder}')
        base = root / folder
        if any((root / Path(*rel.parts[:i])).is_symlink() for i in range(1, len(rel.parts) + 1)):
            raise ValueError(f'symlink disallowed in editorial evidence: {base}')
        if base.exists():
            for path in sorted(base.rglob('*')) if base.is_dir() else [base]:
                if path.is_symlink():
                    raise ValueError(f'symlink disallowed in editorial evidence: {path}')
                if path.is_file() and '__pycache__' not in path.parts and path.suffix not in {'.pyc', '.pyo'}:
                    selected[path.relative_to(root).as_posix()] = path.read_bytes()
    return selected


def compare(before, after):
    # Use the baseline policy for both trees: edited policy cannot narrow protection.
    paths = json.loads((before / POLICY).read_text())['scientific_paths']
    context = before / 'SNAPSHOT_CONTEXT.json'
    if context.exists():
        paths = [*paths, *json.loads(context.read_text())['public_inputs']]
    old, new = files(before, paths), files(after, paths)
    errors = []
    if 'paper/main.tex' not in old or 'paper/main.tex' not in new:
        errors.append({'missing_authority': 'paper/main.tex must exist in both trees'})
    if set(old) != set(new):
        errors.append({'file_set_changed': sorted(set(old) ^ set(new))})
    for name in sorted(set(old) & set(new)):
        if (name.startswith(('paper/', 'sections/')) and name.endswith('.tex')
                and not name.endswith(('defs.tex', 'definitions.tex', 'macros.tex'))):
            first, second = invariants(old[name]), invariants(new[name])
            changed = [key for key in first if first[key] != second[key]]
            if changed:
                errors.append({'path': name, 'changed_invariants': changed})
        elif old[name] != new[name]:
            errors.append({'path': name, 'scientific_payload_changed': True,
                           'before_sha256': digest(old[name]), 'after_sha256': digest(new[name])})
    return {'passed': not errors, 'files_compared': len(set(old) & set(new)), 'errors': errors,
            'limits': 'Necessary checks only. Manual diff audit must verify unchanged scientific claims, assumptions and meaning. Regex math detection does not implement the full TeX grammar; prose numerals, macro definitions and command spelling are intentionally conservatively protected. Commands protected through line end may reject adjacent prose edits. PDF/log bytes are rebuilt separately, not required to remain identical.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    args = parser.parse_args()
    try:
        result = compare(args.before.resolve(), args.after.resolve())
        print(json.dumps(result, indent=2))
        return 0 if result['passed'] else 1
    except (ValueError, OSError, UnicodeError, KeyError, TypeError) as exc:
        parser.error(str(exc))


if __name__ == '__main__':
    raise SystemExit(main())
